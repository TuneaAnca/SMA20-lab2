package com.example.helloandroid;

import androidx.appcompat.app.AppCompatActivity;


import android.app.AlertDialog;
import android.app.Dialog;
import android.app.SearchManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Spinner;
import android.widget.TextView;

import static android.widget.Toast.LENGTH_SHORT;
import static android.widget.Toast.makeText;


public class MainActivity extends AppCompatActivity {

    EditText eName;
    Button bClick, bShare, bSearch;;
    TextView tName;

    Button closeButton;
    AlertDialog.Builder builder;

    Button showPopupBtn, closePopupBtn;
    PopupWindow popupWindow;
    LinearLayout linearLayout1;

    Spinner spinner;
    Intent sendIntent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




        try {
            eName = (EditText) findViewById(R.id.editText);
            bClick = (Button) findViewById(R.id.button2);
            tName = (TextView) findViewById(R.id.textView2);
            spinner = (Spinner) findViewById(R.id.spinner);
            bShare = (Button) findViewById(R.id.bShare);
            bSearch = (Button) findViewById(R.id.bSearch);


        } catch (NullPointerException e) {
            throw new IllegalStateException("This is not possible", e);
        }

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.colors_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        builder = new AlertDialog.Builder(getApplicationContext());



        bClick.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tName.setText("Hello " + eName.getText());


            }

        });




        closeButton = (Button) findViewById(R.id.button);
        builder = new AlertDialog.Builder(this);
        closeButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                //Uncomment the below code to Set the message and title from the strings.xml file
                builder.setMessage(R.string.dialog_message).setTitle(R.string.dialog_title);

                //Setting message manually and performing action on button click
                builder.setMessage("Do you want to close this application ?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                finish();
                                makeText(getApplicationContext(), "you choose yes action for alertbox",
                                        LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Action for 'NO' Button
                                dialog.cancel();
                                makeText(getApplicationContext(), "you choose no action for alertbox",
                                        LENGTH_SHORT).show();
                            }
                        });
                //Creating dialog box
                AlertDialog alert = builder.create();
                //Setting the title manually
                alert.setTitle("AlertDialogExample");
                alert.show();
            }
        });





        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            //@Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i) {
                    case 0: bClick.setTextColor(Color.BLUE);
                        break;
                    case 1: bClick.setTextColor(Color.GREEN);
                        break;
                    case 2: bClick.setTextColor(Color.RED);
                        break;
                    case 3: bClick.setTextColor(Color.YELLOW);
                        break;
                }
            }

           // @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                bClick.setTextColor(Color.BLACK);
            }
        });

        bShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendIntent = new Intent();

                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, eName.getText().toString());
                sendIntent.setType("text/plain");

                Intent shareIntent = Intent.createChooser(sendIntent, null);
                startActivity(shareIntent);
            }
        });


        bSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_WEB_SEARCH);
                intent.putExtra(SearchManager.QUERY,  eName.getText().toString());
                startActivity(intent);
            }
        });

    }
}